import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { View, Text, Button, SafeAreaView } from 'react-native';
import lista from './lista';

const Page = styled.SafeAreaView`
  flex: 1;
`;

const Item = styled.TouchableOpacity`
  peding: 10px;
  flex-direction: row;
`;

const Linha = styled.Text`
  flex: 1;
  font-size: 20px;
`;

const Quebra = styled.Text`
  font-size: 5px;
`;

const Titulo = styled.Text`
  font-size: 40px;
  font-weight: bold;
  color: #6b21a8;
`;

const ItemText = styled.Text`
  font-size: 20px;
  font-weight: bold;
  color: #6b21a8;
`;

const Scroll = styled.ScrollView`
  flex: 1;
  align-items: stretch;
  width: 300px;
  border: 5px #4c1d95;
  background-color: #c7d2fe;
  max-height: 200px;
  margin: 25px;
  border-radius: 5px
`;

const ItemCheck = styled.View`
  width: 20px;
  height: 20px;
  border-radius: 10px;
  border: 5px solid #4c1d95;
`;

export default () => {
  return (
    <Page>
      <ItemText></ItemText>
      <Scroll>
        {lista.map((item, index)=>{
          return (
            <Item key = {index}>
              <>
                <ItemText>{item.task}</ItemText>
                <Linha></Linha>
                {item.done == true &&
                  <ItemCheck></ItemCheck>
                }
                <Quebra></Quebra>
              </>
            </Item>
          );
        })}
      </Scroll>
    </Page>
  );
}