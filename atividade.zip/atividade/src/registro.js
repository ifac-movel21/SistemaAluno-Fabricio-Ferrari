import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { View, Text, SafeAreaView } from 'react-native';
import { Input, Stack, Center, Heading, Button, NativeBaseProvider } from "native-base";
import imprimir from "./imprimir1";

const Scroll = styled.ScrollView`
  flex: 1;
`;

const Scroll2 = styled.ScrollView`
  flex: 1;
  align-items: stretch;
  width: 300px;
  border: 5px #4c1d95;
  background-color: #c7d2fe;
  max-height: 150px;
  margin: 25px;
  border-radius: 5px
`
const ItemText = styled.Text`
  font-size: 20px;
  font-weight: bold;
  color: #6b21a8;
`;

const Quebra = styled.Text`
  font-size: 40px;
`;
const Linha = styled.Text`
  flex:1;
`;
const Imp = ()=>{
  return imprimir();
}
export default () =>{
  const [ nome, setNome ] = useState('');
  const [ curso, setCurso ] = useState('');
  const [ disciplina, setdisciplina ] = useState('');
  const [ nota1, setNota1 ] = useState(0);
  const [ nota2, setNota2 ] = useState(0);
  const [ qtdFaltas, setQtdFaltas ] = useState(0);
  const [ qtdEncontros, setQtdEncontros ] = useState(0);
  const [ pct, setPct ] = useState (0);
  const [ pct2, setPct2 ] = useState (0);
  const Media = ()=>{
    let nNota1 = parseFloat(nota1);
    let nNota2 = parseFloat(nota2);
    return ((nNota1 + nNota2)/2);
  }
  const Encontros = () =>{
    let nqtdEncontros = parseFloat(qtdEncontros);
    return (nqtdEncontros * 0.25);
  }
  const Apro = () =>{
    let nqtdFaltas = parseFloat(qtdFaltas);
    if(((parseFloat(nota1) +parseFloat(nota2))/2)>=7){
      if((parseFloat(qtdEncontros)* 0.25)>(nqtdFaltas)){
        return "Aprovado";
      }else{
        return "Reprovado por Faltas";
      }
    }else{
      return "Reprovado";
    }
  }

  const Atv = () =>{
    return(
      <NativeBaseProvider>
          <Button onPress={()=>setPct2(0)}>Voltar</Button>
          <ItemText>Lista de Atividades</ItemText>
          <Imp/>
      </NativeBaseProvider>);
  }

  return (
      <>
        <Scroll>
          <NativeBaseProvider>
            <Quebra></Quebra>
            <Center>
              <Stack space={4} w="100%">
            <Center>
              <Heading>Calculadora Acadêmica</Heading>
            </Center>
            <Input
              size="md"
              placeholder="Nome"
              _light={{
                placeholderTextColor: "blueGray.400",
              }}
              _dark={{
                placeholderTextColor: "blueGray.50",
              }}
              value = {nome}
              onChangeText = { n=>setNome(n) }
            />
            <Input
              size="md"
              placeholder="Curso"
              _light={{
                placeholderTextColor: "blueGray.400",
              }}
              _dark={{
                placeholderTextColor: "blueGray.50",
              }}
              value = {curso}
              onChangeText = { c=>setCurso(c) }
            />
            <Input
              size="md"
              placeholder="Disciplina"
              _light={{
                placeholderTextColor: "blueGray.400",
              }}
              _dark={{
                placeholderTextColor: "blueGray.50",
              }}
              value = {disciplina}
              onChangeText = { d=>setdisciplina(d) }
            />
            <Input
              size="md"
              placeholder="Nota 1"
              _light={{
                placeholderTextColor: "blueGray.400",
              }}
              _dark={{
                placeholderTextColor: "blueGray.50",
              }}
              keyboardType = "numeric"
              value = {nota1}
              onChangeText = { n1=>setNota1(n1) }
            />
            <Input
              size="md"
              placeholder="Nota 2"
              _light={{
                placeholderTextColor: "blueGray.400",
              }}
              _dark={{
                placeholderTextColor: "blueGray.50",
              }}
              keyboardType = "numeric"
              value = {nota2}
              onChangeText = { n2=>setNota2(n2) }
            />
            <Input
              size="md"
              placeholder="Quantidade de Faltas"
              _light={{
                placeholderTextColor: "blueGray.400",
              }}
              _dark={{
                placeholderTextColor: "blueGray.50",
              }}
              keyboardType = "numeric"
              value = {qtdFaltas}
              onChangeText = { qF=>setQtdFaltas(qF) }
            />
            <Input
              size="md"
              placeholder="Quantidade de Encontros"
              _light={{
                placeholderTextColor: "blueGray.400",
              }}
              _dark={{
                placeholderTextColor: "blueGray.50",
              }}
              keyboardType = "numeric"
              value = {qtdEncontros}
              onChangeText = { qE=>setQtdEncontros(qE) }
            />
          </Stack>
              <Quebra />
              <Linha>
                <Button onPress={()=>setPct(5)}>Gerar</Button>
                <Linha>                  </Linha>
                <Button onPress={()=>setPct(0)}>Esconder</Button>
              </Linha>
              <Linha></Linha>
              <Linha></Linha>
            </Center>
          </NativeBaseProvider>
          {pct > 0 &&
          <NativeBaseProvider>
            <Center>
              <Scroll>
                <ItemText>Nome:  {nome}</ItemText>
                <Linha></Linha>
                <ItemText>Curso:  {curso}</ItemText>
                <Linha></Linha>
                <ItemText>Disciplina:  {disciplina}</ItemText>
                <Linha></Linha>
                <ItemText>Nota da N1:  {nota1}</ItemText>
                <Linha></Linha>
                <ItemText>Nota da N2:  {nota2}</ItemText>
                <Linha></Linha>
                <ItemText>Média:  <Media/></ItemText>
                <Linha></Linha>
                <ItemText>Quantidade de Encontros:  {parseInt(qtdEncontros)}</ItemText>
                <Linha></Linha>
                <ItemText>Quantidade de Faltas:  {parseFloat(qtdFaltas)}</ItemText>
                <Linha></Linha>
                <ItemText>Quantidade de Faltas permitidas:  <Encontros/></ItemText>
                <Linha></Linha>
                <ItemText>Estatus do Aluno:  <Apro/></ItemText>
                <Linha></Linha>
                <ItemText>Mostrar Lista de Atividades:</ItemText>
                <Linha></Linha>
                <Button onPress={()=>setPct2(5)}>Mostrar</Button>
              </Scroll>
            </Center>
          </NativeBaseProvider>
          }
          
        </Scroll>
        {pct2 > 0 &&
          <Atv/>
        }
      </>
  );
  
}
