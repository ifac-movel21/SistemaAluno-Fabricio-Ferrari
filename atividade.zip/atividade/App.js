import React, { useState, useEffect, Component } from 'react';
import styled from 'styled-components';
import { View, Text, SafeAreaView } from 'react-native';
import { Input, Stack, Center, Heading, Button, NativeBaseProvider } from "native-base";
import registro from './src/registro';


export default () => {
  return (registro());
}
